// SPDX-License-Identifier: Unlicensed

pragma solidity >=0.7.0 <0.9.0;

import "https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v4.9.3/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v4.9.3/contracts/access/Ownable.sol";

contract Comp1830NFT is ERC721Enumerable, Ownable {

   using Strings for uint256;

   string public baseURI; 
   uint256 public maxSupply = 10; // max total nft 

   constructor(
       string memory _name, // token name 
       string memory _symbol, // token symbol 
       string memory _initBaseURI // token metdata 
   ) ERC721(_name, _symbol) {
       setBaseURI(_initBaseURI);
       mint(msg.sender, 5); // mint at the initial run 
   }
   

   function _baseURI() internal view virtual override returns (string memory) {
       return baseURI;
   }

   function mint(address _to, uint256 _mintAmount) public payable {
       uint256 supply = totalSupply();
       require(_mintAmount > 0);
       require(supply + _mintAmount <= maxSupply);

       for (uint256 i = 1; i <= _mintAmount; i++) {
           _safeMint(_to, supply + i);
       }
   }

   function setBaseURI(string memory _newBaseURI) public onlyOwner {
       baseURI = _newBaseURI;
   }

}