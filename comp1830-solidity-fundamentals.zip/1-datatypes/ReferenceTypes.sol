// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

contract ReferenceTypes {
    
    struct Student {
        string name;
        uint256 grade;
    }

    mapping(address => Student) public studentRegistry;
    Student[10] public class;

}

