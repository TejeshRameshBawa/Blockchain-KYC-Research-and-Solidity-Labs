// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

contract  RestrictedUniModule{
        
    address public moduleLeader;
    address public moduleRep;

    struct Student {
        string name;
        string studentID;
        uint256 grade;
    }
    mapping(address => Student) public studentRegistry;

    uint256 public registrationPrice;

    modifier onlyModuleLeader {
        require(msg.sender == moduleLeader, "This can only be invoked by module leader");
        _;
    }

    constructor(uint256 _registrationPrice) {
        moduleLeader = msg.sender;
        registrationPrice = _registrationPrice;
    }

    function registry(string memory _name, string memory _studentID) public payable returns (bool){
        require(msg.value == registrationPrice, "Incorrect amount sent with registration!");
        Student memory mystudent = Student(
            _name, _studentID, 0 
        );
        studentRegistry[msg.sender] = mystudent;
        return true;
    }

    function setModuleRep(address _moduleRep) public onlyModuleLeader returns (bool) {
        require(bytes(studentRegistry[_moduleRep].name).length != 0, "This address is not registered" );
        moduleRep = _moduleRep;
        return true;
    }

}
