// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

contract  UniModule{

    address public moduleLeader;
    address public moduleRep;
        
    // Add your code here
    constructor(address _moduleRep) {
        moduleRep = _moduleRep;
        moduleLeader = msg.sender;
    }

}

