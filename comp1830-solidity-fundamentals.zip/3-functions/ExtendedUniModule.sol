// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

contract  ExtendedUniModule{
        
    address public moduleLeader;
    address public moduleRep;

    struct Student {
        string name;
        string studentID;
        uint256 grade;
    }

    mapping(address => Student) public studentRegistry;
        
    // Add your code here
    constructor() {
        moduleLeader = msg.sender;
    }

    function register(string calldata _name, string calldata _studentID) public {
        Student memory mystudent = Student(_name, _studentID, 0);
        studentRegistry[msg.sender] = mystudent;
    }

    function setModuleRep (address _moduleRep) public returns(bool) {
        require(bytes(studentRegistry[_moduleRep].name).length > 0, "Student not registered");
        moduleRep = _moduleRep;
        return true;
    }


}
